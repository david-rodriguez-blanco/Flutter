package com.mycompany.bluetoothtest1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
