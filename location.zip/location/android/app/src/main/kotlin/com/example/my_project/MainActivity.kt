package com.mycompany.location

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
