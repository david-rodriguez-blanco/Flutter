package com.mycompany.bluetoothtest3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
